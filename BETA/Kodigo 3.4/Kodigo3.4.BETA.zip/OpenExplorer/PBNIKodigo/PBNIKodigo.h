// PBNIKodigo.h : include file for standard system include files,
//  or project specific include files that are used frequently,
//  are changed infrequently
//

#ifndef PBNIKODIGO_H
#define PBNIKODIGO_H

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

// Insert your headers here
#include <windows.h>

// TODO: reference additional headers your program requires here

#endif // !defined(PBNIKODIGO_H)
