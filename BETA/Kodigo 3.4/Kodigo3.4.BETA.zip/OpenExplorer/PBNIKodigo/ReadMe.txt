========================================================================
    PBNIWizard : "PBNISubclass" Project Overview
========================================================================

PBNIWizard has created this "PBNISubclass" project for you as a starting point.

This file contains a summary of what you will find in each of the files that make up your project.

PBNIWizard.vcproj
    This is the main project file for projects generated using an Application Wizard. 
    It contains information about the version of the product that generated the file, and 
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

My.cpp
This is the source file for the PBNI class.

My.h
This is the header file for the PBNI class.

PBNISubclass.cpp
This is the main source file for the PBNI DLL

PBNISubclass.h
This is the main header file for the PBNI DLL

/////////////////////////////////////////////////////////////////////////////
Other notes:

/////////////////////////////////////////////////////////////////////////////
